// Function to show an alert
function showAlert() {
    alert('Terima kasih !');
}
